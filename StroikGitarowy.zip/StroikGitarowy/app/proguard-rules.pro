# Domyślne reguły wystarczą – biblioteki Google dostarczają własne.
