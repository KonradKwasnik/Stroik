plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

// Dane z sekretów GitHuba (w Actions) – nic tajnego nie trafia do repozytorium
fun env(name: String): String? = System.getenv(name)?.takeIf { it.isNotBlank() }

android {
    namespace = "pl.stroik.gitara"
    compileSdk = 36

    defaultConfig {
        // Unikalny identyfikator w Google Play – po pierwszej publikacji NIE DA SIĘ go zmienić
        applicationId = "com.konradkwasnik.tuner"
        minSdk = 24
        targetSdk = 36
        // Numer wersji rośnie sam z każdym budowaniem na GitHubie (sklep tego wymaga)
        versionCode = env("GITHUB_RUN_NUMBER")?.toInt() ?: 1
        versionName = "1.0." + (env("GITHUB_RUN_NUMBER") ?: "0")
    }

    signingConfigs {
        env("KEYSTORE_PATH")?.let { path ->
            create("release") {
                storeFile = file(path)
                storePassword = env("KEYSTORE_PASSWORD")
                keyAlias = env("KEY_ALIAS")
                keyPassword = env("KEY_PASSWORD")
            }
        }
    }

    buildTypes {
        debug {
            // Testowe ID od Google – bezpieczne do testów, nie zarabiają
            manifestPlaceholders["admobAppId"] = "ca-app-pub-3940256099942544~3347511713"
            buildConfigField("String", "BANNER_AD_UNIT_ID", "\"ca-app-pub-3940256099942544/9214589741\"")
        }
        release {
            // Prawdziwe ID z AdMob z sekretów ADMOB_APP_ID / ADMOB_BANNER_ID;
            // dopóki ich nie ma – testowe (aplikacja działa, ale nie zarabia)
            manifestPlaceholders["admobAppId"] =
                env("ADMOB_APP_ID") ?: "ca-app-pub-3940256099942544~3347511713"
            buildConfigField("String", "BANNER_AD_UNIT_ID",
                "\"" + (env("ADMOB_BANNER_ID") ?: "ca-app-pub-3940256099942544/9214589741") + "\"")
            signingConfig = signingConfigs.findByName("release")
            isMinifyEnabled = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures {
        compose = true
        buildConfig = true
    }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2024.12.01")
    implementation(composeBom)
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.ui:ui-tooling-preview")
    debugImplementation("androidx.compose.ui:ui-tooling")

    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.7")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")

    // Reklamy AdMob + zgoda RODO (UMP)
    implementation("com.google.android.gms:play-services-ads:23.6.0")
    implementation("com.google.android.ump:user-messaging-platform:3.1.0")
}
