package pl.stroik.gitara

import android.app.Activity
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.viewinterop.AndroidView
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.MobileAds
import com.google.android.ump.ConsentInformation
import com.google.android.ump.ConsentRequestParameters
import com.google.android.ump.UserMessagingPlatform
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Zgoda RODO (wymagana w UE) + inicjalizacja AdMob.
 * Okno zgody konfigurujesz w konsoli AdMob: Prywatność i wiadomości → RODO.
 */
object AdsManager {
    private val initialized = AtomicBoolean(false)

    fun gatherConsentAndInit(activity: Activity, onReady: () -> Unit) {
        val consent = UserMessagingPlatform.getConsentInformation(activity)
        val params = ConsentRequestParameters.Builder().build()

        consent.requestConsentInfoUpdate(activity, params, {
            UserMessagingPlatform.loadAndShowConsentFormIfRequired(activity) {
                if (consent.canRequestAds()) init(activity, onReady)
            }
        }, {
            // Błąd sieci itp. – spróbuj z poprzednią zgodą
            if (consent.canRequestAds()) init(activity, onReady)
        })

        // Zgoda z poprzedniej sesji – nie czekaj
        if (consent.canRequestAds()) init(activity, onReady)
    }

    /** Czy pokazać przycisk zmiany zgody (wymagane przez RODO w UE). */
    fun privacyOptionsRequired(activity: Activity): Boolean =
        UserMessagingPlatform.getConsentInformation(activity).privacyOptionsRequirementStatus ==
            ConsentInformation.PrivacyOptionsRequirementStatus.REQUIRED

    fun showPrivacyOptions(activity: Activity) {
        UserMessagingPlatform.showPrivacyOptionsForm(activity) { }
    }

    private fun init(activity: Activity, onReady: () -> Unit) {
        if (!initialized.compareAndSet(false, true)) return
        MobileAds.initialize(activity) { activity.runOnUiThread(onReady) }
    }
}

@Composable
fun AdBanner(modifier: Modifier = Modifier) {
    val widthDp = LocalConfiguration.current.screenWidthDp
    AndroidView(
        modifier = modifier.fillMaxWidth(),
        factory = { ctx ->
            AdView(ctx).apply {
                setAdSize(AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(ctx, widthDp))
                adUnitId = BuildConfig.BANNER_AD_UNIT_ID
                loadAd(AdRequest.Builder().build())
            }
        },
        onRelease = { it.destroy() }
    )
}
