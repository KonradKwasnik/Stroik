package pl.stroik.gitara

import kotlin.math.abs
import kotlin.math.ln
import kotlin.math.pow
import kotlin.math.roundToInt

data class GuitarString(val label: String, val freq: Float)

/** Strojenie standardowe, od najgrubszej struny. */
val STANDARD_TUNING = listOf(
    GuitarString("E2", 82.41f),
    GuitarString("A2", 110.00f),
    GuitarString("D3", 146.83f),
    GuitarString("G3", 196.00f),
    GuitarString("B3", 246.94f),
    GuitarString("E4", 329.63f),
)

private val NOTE_NAMES = listOf("C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "H")

data class TunerReading(
    val frequency: Float,
    val noteName: String,   // najbliższa nuta chromatyczna, np. "A2"
    val cents: Float,       // odchylenie od tej nuty (-50..+50)
    val nearestString: Int, // indeks w STANDARD_TUNING
)

fun cents(freq: Float, target: Float): Float =
    (1200.0 * ln(freq.toDouble() / target) / ln(2.0)).toFloat()

fun analyze(freq: Float): TunerReading {
    // Numer MIDI: A4 = 69 = 440 Hz
    val midi = (69 + 12 * ln(freq / 440.0) / ln(2.0)).roundToInt()
    val noteFreq = (440.0 * 2.0.pow((midi - 69) / 12.0)).toFloat()
    val name = NOTE_NAMES[((midi % 12) + 12) % 12] + (midi / 12 - 1)
    val string = STANDARD_TUNING.indices.minBy { abs(cents(freq, STANDARD_TUNING[it].freq)) }
    return TunerReading(freq, name, cents(freq, noteFreq), string)
}
