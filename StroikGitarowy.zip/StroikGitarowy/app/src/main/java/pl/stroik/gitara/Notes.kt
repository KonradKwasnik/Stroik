package pl.stroik.gitara

import androidx.annotation.StringRes
import java.util.Locale
import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.ln
import kotlin.math.pow
import kotlin.math.roundToInt

/** Struna = numer MIDI (A4 = 69 = 440 Hz). */
data class Instrument(@StringRes val nameRes: Int, val strings: List<Int>)

val INSTRUMENTS = listOf(
    Instrument(R.string.inst_guitar, listOf(40, 45, 50, 55, 59, 64)),   // E2 A2 D3 G3 B3 E4
    Instrument(R.string.inst_bass, listOf(28, 33, 38, 43)),              // E1 A1 D2 G2
    Instrument(R.string.inst_ukulele, listOf(67, 60, 64, 69)),          // G4 C4 E4 A4
    Instrument(R.string.inst_violin, listOf(55, 62, 69, 76)),         // G3 D4 A4 E5
    Instrument(R.string.inst_chromatic, emptyList()),
)

private val NOTE_NAMES = listOf("C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B")

/** W Polsce (i Niemczech) nuta B nazywa się H. */
private val USE_H = Locale.getDefault().language in setOf("pl", "de", "cs", "sk")

fun noteLetter(midi: Int): String {
    val name = NOTE_NAMES[((midi % 12) + 12) % 12]
    return if (USE_H && name == "B") "H" else name
}
fun noteOctave(midi: Int) = floor(midi / 12.0).toInt() - 1
fun noteLabel(midi: Int) = noteLetter(midi) + noteOctave(midi)
fun midiToFreq(midi: Int) = (440.0 * 2.0.pow((midi - 69) / 12.0)).toFloat()

/** Dokładna (ułamkowa) pozycja dźwięku na skali – np. 45.2 to A2 o 20 centów za wysoko. */
fun freqToMidi(freq: Float) = (69 + 12 * ln(freq / 440.0) / ln(2.0)).toFloat()

fun cents(freq: Float, target: Float): Float =
    (1200.0 * ln(freq.toDouble() / target) / ln(2.0)).toFloat()

data class TunerReading(
    val frequency: Float,
    val midiExact: Float,   // ciągła pozycja na kole nut
    val midi: Int,          // najbliższa nuta
    val cents: Float,       // odchylenie od najbliższej nuty
    val stringIndex: Int,   // najbliższa struna wybranego instrumentu (-1 w trybie chromatycznym)
    val stringCents: Float, // odchylenie od tej struny
)

fun analyze(freq: Float, instrument: Instrument): TunerReading {
    val exact = freqToMidi(freq)
    val midi = exact.roundToInt()
    val stringIndex = if (instrument.strings.isEmpty()) -1
        else instrument.strings.indices.minBy { abs(exact - instrument.strings[it]) }
    val stringCents = if (stringIndex < 0) 0f
        else cents(freq, midiToFreq(instrument.strings[stringIndex]))
    return TunerReading(freq, exact, midi, cents(freq, midiToFreq(midi)), stringIndex, stringCents)
}
