package pl.stroik.gitara

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

private val Bg = Color(0xFF121212)
private val InTune = Color(0xFF4CAF50)
private val Close = Color(0xFFFFC107)
private val Off = Color(0xFFF44336)

class MainActivity : ComponentActivity() {
    private val vm: TunerViewModel by viewModels()
    private var adsReady by mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        AdsManager.gatherConsentAndInit(this) { adsReady = true }
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(Modifier.fillMaxSize(), color = Bg) {
                    Column(Modifier.fillMaxSize().systemBarsPadding()) {
                        Box(Modifier.weight(1f)) { TunerScreen(vm) }
                        if (adsReady) AdBanner()
                    }
                }
            }
        }
    }
}

@Composable
fun TunerScreen(vm: TunerViewModel) {
    val ctx = LocalContext.current
    var hasMic by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) ==
                PackageManager.PERMISSION_GRANTED
        )
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        hasMic = it
        if (it) vm.start()
    }

    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { if (hasMic) vm.start() }
    LifecycleEventEffect(Lifecycle.Event.ON_PAUSE) { vm.stop() }

    if (!hasMic) {
        Column(
            Modifier.fillMaxSize().padding(32.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("Stroik potrzebuje mikrofonu, żeby słyszeć gitarę.", color = Color.White)
            Spacer(Modifier.height(16.dp))
            Button(onClick = { launcher.launch(Manifest.permission.RECORD_AUDIO) }) {
                Text("Zezwól na mikrofon")
            }
        }
        return
    }

    val reading by vm.reading.collectAsStateWithLifecycle()
    val cents = reading?.cents ?: 0f
    val color by animateColorAsState(
        when {
            reading == null -> Color.Gray
            abs(cents) <= 5 -> InTune
            abs(cents) <= 15 -> Close
            else -> Off
        }, label = "color"
    )

    Column(
        Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceEvenly
    ) {
        Text("Stroik Gitarowy", color = Color.White.copy(alpha = 0.6f), fontSize = 18.sp)

        Gauge(cents = if (reading == null) 0f else cents, color = color)

        Text(
            reading?.noteName ?: "–",
            color = color, fontSize = 72.sp, fontWeight = FontWeight.Bold
        )
        Text(
            reading?.let {
                "%.1f Hz   %+.0f ct".format(it.frequency, it.cents)
            } ?: "Zagraj strunę",
            color = Color.White.copy(alpha = 0.7f), fontSize = 18.sp
        )
        Text(
            when {
                reading == null -> ""
                abs(cents) <= 5 -> "Nastrojone ✓"
                cents < 0 -> "Za nisko – dokręć"
                else -> "Za wysoko – poluzuj"
            },
            color = color, fontSize = 20.sp
        )

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            STANDARD_TUNING.forEachIndexed { i, s ->
                val active = reading?.nearestString == i
                Box(
                    Modifier.size(48.dp).clip(CircleShape)
                        .background(if (active) color else Color.White.copy(alpha = 0.1f)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(s.label.dropLast(1), color = if (active) Bg else Color.White, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun Gauge(cents: Float, color: Color) {
    val angle by animateFloatAsState(cents.coerceIn(-50f, 50f) * 1.6f, label = "needle")
    Canvas(Modifier.fillMaxWidth().height(160.dp)) {
        val center = Offset(size.width / 2, size.height)
        val r = size.height * 0.95f
        // Podziałka co 10 centów
        for (c in -50..50 step 10) {
            val a = Math.toRadians((c * 1.6f - 90).toDouble())
            val len = if (c == 0) 28f else 16f
            val start = Offset(center.x + (r - len) * cos(a).toFloat(), center.y + (r - len) * sin(a).toFloat())
            val end = Offset(center.x + r * cos(a).toFloat(), center.y + r * sin(a).toFloat())
            drawLine(if (c == 0) InTune else Color.White.copy(alpha = 0.4f), start, end, 4f)
        }
        val a = Math.toRadians((angle - 90).toDouble())
        val tip = Offset(center.x + (r - 10) * cos(a).toFloat(), center.y + (r - 10) * sin(a).toFloat())
        drawLine(color, center, tip, 8f, cap = StrokeCap.Round)
        drawCircle(color, 12f, center)
    }
}
