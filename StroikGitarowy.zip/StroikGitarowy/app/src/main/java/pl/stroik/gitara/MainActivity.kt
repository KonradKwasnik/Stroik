package pl.stroik.gitara

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.roundToInt
import kotlin.math.sin

private val Bg = Color(0xFF121212)
private val Panel = Color(0xFF1E1E1E)
private val InTune = Color(0xFF4CAF50)
private val Close = Color(0xFFFFC107)
private val Off = Color(0xFFF44336)

class MainActivity : ComponentActivity() {
    private val vm: TunerViewModel by viewModels()
    private var adsReady by mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        AdsManager.gatherConsentAndInit(this) { adsReady = true }
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(Modifier.fillMaxSize(), color = Bg) {
                    Column(Modifier.fillMaxSize().systemBarsPadding()) {
                        if (adsReady) AdBanner()   // banner na górze
                        // Na tablecie treść ma rozsądną szerokość i jest na środku
                        Box(
                            Modifier.weight(1f).fillMaxWidth(),
                            contentAlignment = Alignment.TopCenter
                        ) {
                            Box(Modifier.widthIn(max = 560.dp).fillMaxHeight()) { TunerScreen(vm) }
                        }
                        if (adsReady && AdsManager.privacyOptionsRequired(this@MainActivity)) {
                            TextButton(
                                onClick = { AdsManager.showPrivacyOptions(this@MainActivity) },
                                modifier = Modifier.align(Alignment.CenterHorizontally)
                            ) {
                                Text(
                                    stringResource(R.string.privacy_settings),
                                    color = Color.White.copy(alpha = 0.5f), fontSize = 12.sp
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun TunerScreen(vm: TunerViewModel) {
    val ctx = LocalContext.current
    var hasMic by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) ==
                PackageManager.PERMISSION_GRANTED
        )
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        hasMic = it
        if (it) vm.start()
    }

    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { if (hasMic) vm.start() }
    LifecycleEventEffect(Lifecycle.Event.ON_PAUSE) { vm.stop() }

    if (!hasMic) {
        Column(
            Modifier.fillMaxSize().padding(32.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(stringResource(R.string.mic_needed), color = Color.White)
            Spacer(Modifier.height(16.dp))
            Button(onClick = { launcher.launch(Manifest.permission.RECORD_AUDIO) }) {
                Text(stringResource(R.string.allow_mic))
            }
        }
        return
    }

    // Wybrany instrument zapamiętywany między uruchomieniami
    val prefs = remember { ctx.getSharedPreferences("stroik", Context.MODE_PRIVATE) }
    var instIndex by remember {
        mutableIntStateOf(prefs.getInt("instrument", 0).coerceIn(INSTRUMENTS.indices))
    }
    val instrument = INSTRUMENTS[instIndex]

    val freq by vm.frequency.collectAsStateWithLifecycle()
    val reading = freq?.let { analyze(it, instrument) }
    val chromatic = instrument.strings.isEmpty()
    // W trybie instrumentu wskazówka pokazuje odchylenie od struny, w chromatycznym – od nuty
    val shownCents = reading?.let { if (chromatic) it.cents else it.stringCents } ?: 0f

    val color by animateColorAsState(
        when {
            reading == null -> Color.Gray
            abs(shownCents) <= 5 -> InTune
            abs(shownCents) <= 15 -> Close
            else -> Off
        }, label = "color"
    )

    Column(
        Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        InstrumentPicker(instIndex) {
            instIndex = it
            prefs.edit().putInt("instrument", it).apply()
        }

        Gauge(cents = shownCents.coerceIn(-50f, 50f), color = color)

        // Duża nuta z oktawą
        Row(verticalAlignment = Alignment.Bottom) {
            Text(
                reading?.let { noteLetter(it.midi) } ?: "–",
                color = color, fontSize = 80.sp, fontWeight = FontWeight.Bold
            )
            if (reading != null) {
                Text(
                    noteOctave(reading.midi).toString(),
                    color = color.copy(alpha = 0.8f), fontSize = 30.sp,
                    modifier = Modifier.padding(bottom = 14.dp, start = 2.dp)
                )
            }
        }
        Text(
            reading?.let { "%.1f Hz   %+.0f ct".format(it.frequency, it.cents) } ?: stringResource(R.string.play_note),
            color = Color.White.copy(alpha = 0.7f), fontSize = 16.sp
        )

        NoteWheel(midiExact = reading?.midiExact, color = color)

        Text(
            when {
                reading == null -> " "
                abs(shownCents) <= 5 -> stringResource(R.string.in_tune)
                shownCents < 0 -> stringResource(R.string.too_low)
                else -> stringResource(R.string.too_high)
            },
            color = color, fontSize = 20.sp
        )

        if (!chromatic) StringRow(instrument, reading, color) else Spacer(Modifier.height(56.dp))
    }
}

@Composable
fun InstrumentPicker(selected: Int, onSelect: (Int) -> Unit) {
    Row(
        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        INSTRUMENTS.forEachIndexed { i, inst ->
            val active = i == selected
            Box(
                Modifier.clip(RoundedCornerShape(50))
                    .background(if (active) InTune else Panel)
                    .clickable { onSelect(i) }
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                Text(stringResource(inst.nameRes), color = if (active) Bg else Color.White, fontWeight = FontWeight.Medium)
            }
        }
    }
}

/**
 * Koło nut: pasek z dźwiękami wokół granego, przesuwa się płynnie.
 * Środek paska to dokładnie zagrany dźwięk; pod każdą nutą jej częstotliwość.
 */
@Composable
fun NoteWheel(midiExact: Float?, color: Color) {
    val last = remember { floatArrayOf(57f) } // A3 na start; pamięta ostatni dźwięk
    if (midiExact != null) last[0] = midiExact
    val pos by animateFloatAsState(
        last[0], spring(stiffness = Spring.StiffnessLow), label = "wheel"
    )

    BoxWithConstraints(
        Modifier.fillMaxWidth().height(92.dp)
            .clip(RoundedCornerShape(16.dp)).background(Panel)
    ) {
        val spacing = maxWidth / 5          // 5 nut widocznych naraz
        val center = maxWidth / 2
        val first = floor(pos).toInt() - 3
        val nearest = pos.roundToInt()

        for (m in first..first + 7) {
            val dist = abs(m - pos)
            val alpha = (1f - dist / 3f).coerceIn(0.15f, 1f)
            val isNearest = midiExact != null && m == nearest
            val c = if (isNearest) color else Color.White
            Column(
                Modifier.offset(x = center + spacing * (m - pos) - spacing / 2)
                    .width(spacing).fillMaxHeight(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Row(verticalAlignment = Alignment.Bottom) {
                    Text(
                        noteLetter(m), color = c.copy(alpha = alpha),
                        fontSize = if (isNearest) 32.sp else 24.sp, fontWeight = FontWeight.Bold
                    )
                    Text(
                        noteOctave(m).toString(), color = c.copy(alpha = alpha * 0.8f),
                        fontSize = 13.sp, modifier = Modifier.padding(bottom = 4.dp)
                    )
                }
                Text(
                    "%.1f".format(midiToFreq(m)),
                    color = Color.White.copy(alpha = alpha * 0.5f), fontSize = 11.sp
                )
            }
        }
        // Znacznik środka (aktualnie grany dźwięk)
        Box(
            Modifier.align(Alignment.BottomCenter).width(4.dp).height(14.dp)
                .clip(RoundedCornerShape(topStart = 2.dp, topEnd = 2.dp)).background(color)
        )
        Box(
            Modifier.align(Alignment.TopCenter).width(4.dp).height(14.dp)
                .clip(RoundedCornerShape(bottomStart = 2.dp, bottomEnd = 2.dp)).background(color)
        )
    }
}

@Composable
fun StringRow(instrument: Instrument, reading: TunerReading?, color: Color) {
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        instrument.strings.forEachIndexed { i, midi ->
            val active = reading?.stringIndex == i
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    when {
                        !active || reading == null -> " "
                        reading.stringCents < -5 -> "▲"
                        reading.stringCents > 5 -> "▼"
                        else -> "✓"
                    },
                    color = color, fontSize = 14.sp
                )
                Box(
                    Modifier.size(52.dp).clip(CircleShape)
                        .background(if (active) color else Color.White.copy(alpha = 0.1f)),
                    contentAlignment = Alignment.Center
                ) {
                    Row(verticalAlignment = Alignment.Bottom) {
                        Text(
                            noteLetter(midi), color = if (active) Bg else Color.White,
                            fontWeight = FontWeight.Bold, fontSize = 18.sp
                        )
                        Text(
                            noteOctave(midi).toString(), color = if (active) Bg else Color.White,
                            fontSize = 11.sp, modifier = Modifier.padding(bottom = 2.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun Gauge(cents: Float, color: Color) {
    val angle by animateFloatAsState(cents * 1.6f, label = "needle")
    Canvas(Modifier.fillMaxWidth().height(150.dp)) {
        val center = Offset(size.width / 2, size.height)
        val r = size.height * 0.95f
        // Podziałka co 5 centów, dłuższe kreski co 10
        for (c in -50..50 step 5) {
            val a = Math.toRadians((c * 1.6f - 90).toDouble())
            val len = when {
                c == 0 -> 30f
                c % 10 == 0 -> 18f
                else -> 10f
            }
            val start = Offset(center.x + (r - len) * cos(a).toFloat(), center.y + (r - len) * sin(a).toFloat())
            val end = Offset(center.x + r * cos(a).toFloat(), center.y + r * sin(a).toFloat())
            drawLine(if (c == 0) InTune else Color.White.copy(alpha = 0.4f), start, end, 4f)
        }
        val a = Math.toRadians((angle - 90).toDouble())
        val tip = Offset(center.x + (r - 10) * cos(a).toFloat(), center.y + (r - 10) * sin(a).toFloat())
        drawLine(color, center, tip, 8f, cap = StrokeCap.Round)
        drawCircle(color, 12f, center)
    }
}
