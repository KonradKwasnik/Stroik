package pl.stroik.gitara

/**
 * Wykrywanie wysokości dźwięku algorytmem YIN.
 * Zwraca częstotliwość w Hz albo -1, gdy sygnał jest za cichy lub niejednoznaczny.
 */
class PitchDetector(private val sampleRate: Int, bufferSize: Int) {

    private val halfSize = bufferSize / 2
    private val yin = FloatArray(halfSize)
    private val threshold = 0.15f

    fun detect(buffer: FloatArray): Float {
        // Bramka głośności – ignoruj ciszę i szum tła
        var rms = 0.0
        for (s in buffer) rms += s * s
        rms = Math.sqrt(rms / buffer.size)
        if (rms < 0.01) return -1f

        // 1. Funkcja różnicowa
        for (tau in 0 until halfSize) {
            var sum = 0f
            for (i in 0 until halfSize) {
                val d = buffer[i] - buffer[i + tau]
                sum += d * d
            }
            yin[tau] = sum
        }

        // 2. Skumulowana średnia znormalizowana
        yin[0] = 1f
        var running = 0f
        for (tau in 1 until halfSize) {
            running += yin[tau]
            yin[tau] = if (running == 0f) 1f else yin[tau] * tau / running
        }

        // 3. Pierwsze minimum poniżej progu (od ~1200 Hz w dół)
        val minTau = sampleRate / 1200
        var tauEstimate = -1
        var tau = minTau
        while (tau < halfSize) {
            if (yin[tau] < threshold) {
                while (tau + 1 < halfSize && yin[tau + 1] < yin[tau]) tau++
                tauEstimate = tau
                break
            }
            tau++
        }
        if (tauEstimate == -1) return -1f

        // 4. Interpolacja paraboliczna dla większej dokładności
        val better = if (tauEstimate in 1 until halfSize - 1) {
            val s0 = yin[tauEstimate - 1]
            val s1 = yin[tauEstimate]
            val s2 = yin[tauEstimate + 1]
            val denom = 2f * (2f * s1 - s2 - s0)
            if (denom != 0f) tauEstimate + (s2 - s0) / denom else tauEstimate.toFloat()
        } else tauEstimate.toFloat()

        return sampleRate / better
    }
}
