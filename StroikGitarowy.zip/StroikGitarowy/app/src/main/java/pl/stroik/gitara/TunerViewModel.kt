package pl.stroik.gitara

import android.annotation.SuppressLint
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class TunerViewModel : ViewModel() {

    private val sampleRate = 44100
    private val bufferSize = 4096

    private val _reading = MutableStateFlow<TunerReading?>(null)
    val reading: StateFlow<TunerReading?> = _reading

    private var job: Job? = null
    private var smoothed = -1f

    @SuppressLint("MissingPermission") // uprawnienie sprawdzane w MainActivity
    fun start() {
        if (job?.isActive == true) return
        job = viewModelScope.launch(Dispatchers.Default) {
            val minBuf = AudioRecord.getMinBufferSize(
                sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
            )
            val recorder = AudioRecord(
                MediaRecorder.AudioSource.MIC,
                sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT,
                maxOf(minBuf, bufferSize * 2)
            )
            if (recorder.state != AudioRecord.STATE_INITIALIZED) {
                recorder.release()
                return@launch
            }
            val detector = PitchDetector(sampleRate, bufferSize)
            val pcm = ShortArray(bufferSize)
            val samples = FloatArray(bufferSize)
            recorder.startRecording()
            try {
                while (isActive) {
                    var read = 0
                    while (read < bufferSize && isActive) {
                        val n = recorder.read(pcm, read, bufferSize - read)
                        if (n <= 0) break
                        read += n
                    }
                    if (read < bufferSize) continue
                    for (i in 0 until bufferSize) samples[i] = pcm[i] / 32768f

                    val f = detector.detect(samples)
                    if (f in 60f..1200f) {
                        // Wygładzanie, żeby wskazówka nie skakała
                        smoothed = if (smoothed < 0 || kotlin.math.abs(cents(f, smoothed)) > 50)
                            f else smoothed * 0.7f + f * 0.3f
                        _reading.value = analyze(smoothed)
                    }
                }
            } finally {
                recorder.stop()
                recorder.release()
            }
        }
    }

    fun stop() {
        job?.cancel()
        job = null
    }

    override fun onCleared() = stop()
}
