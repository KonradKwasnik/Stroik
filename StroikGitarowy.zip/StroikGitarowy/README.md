# Stroik Gitarowy – Android + AdMob

Chromatyczny stroik do gitary (strojenie standardowe E A D G H E) z bannerem reklamowym AdMob.
Kotlin + Jetpack Compose, wykrywanie wysokości dźwięku algorytmem YIN.

## Uruchomienie
1. Zainstaluj **Android Studio** (darmowe).
2. File → Open → wskaż folder `StroikGitarowy`. Studio samo pobierze Gradle i biblioteki.
3. Podłącz telefon (Opcje programisty → Debugowanie USB) i kliknij ▶ Run.
4. W wersji debug lecą **testowe reklamy Google** – tak ma być, klikanie ich niczym nie grozi.

## Zarabianie – kroki
1. Załóż konto na **admob.google.com** (potrzebne dane do wypłat i NIP/PESEL do podatku).
2. Dodaj aplikację → skopiuj **App ID** (`ca-app-pub-…~…`).
3. Utwórz jednostkę reklamową **Banner** → skopiuj **Ad unit ID** (`ca-app-pub-…/…`).
4. Wklej oba ID w `app/build.gradle.kts`, w sekcji `release`.
5. W AdMob: **Prywatność i wiadomości → RODO** – utwórz i opublikuj komunikat zgody
   (bez tego w UE reklamy będą słabo płatne albo w ogóle się nie wyświetlą).
6. Zmień `applicationId` na unikalny, np. `pl.twojenazwisko.stroik`.
7. Build → Generate Signed App Bundle (.aab). **Zachowaj plik klucza** – bez niego nie zaktualizujesz aplikacji.
8. Konto w **Google Play Console** (jednorazowo 25 USD), wgraj .aab.
   Nowe konta prywatne muszą przejść test zamknięty: min. 12 testerów przez 14 dni.
9. Wymagana **polityka prywatności** (link w Play Console) – musi wspomnieć mikrofon
   (dźwięk analizowany tylko lokalnie, nic nie jest nagrywane ani wysyłane) oraz reklamy AdMob.

**Nigdy nie klikaj własnych prawdziwych reklam** – AdMob blokuje za to konto.

## Pliki
- `PitchDetector.kt` – algorytm YIN (Hz z próbek audio)
- `Notes.kt` – nuty, struny, odchylenie w centach
- `TunerViewModel.kt` – odczyt mikrofonu w tle
- `Ads.kt` – zgoda RODO (UMP) + banner AdMob
- `MainActivity.kt` – interfejs (wskazówka, nuta, struny)
